// Tableau des départements (à importer dans le modèle)

export const _departements = [
    { id: 1, nom: 'Comptabilité' },
    { id: 2, nom: 'Finances' },
    { id: 3, nom: 'Informatique' },
    { id: 4, nom: 'Marketing' },
    { id: 5, nom: 'Ressources humaines' },
];
